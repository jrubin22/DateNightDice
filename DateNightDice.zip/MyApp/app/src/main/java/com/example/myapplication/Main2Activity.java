package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Random;
import android.view.View.OnClickListener;

public class Main2Activity extends AppCompatActivity {


    String location[] = new String[6];
    String[] activity = new String[6];
    Button shuffle;
    TextView txt2;

    @Override
    protected void onCreate(Bundle savedInstanceState)

    {


        Intent intent = getIntent();
        activity = intent.getStringArrayExtra("activityPass");
        location = intent.getStringArrayExtra("locationPass");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        shuffle = (Button) findViewById(R.id.button4);
        shuffle.setOnClickListener(new View.OnClickListener(){
          @Override
            public void onClick(View view){
              Random rand = new Random();
              Random rand1 = new Random();
              int r1 = rand1.nextInt(location.length-1)+0;
              int r = rand.nextInt(activity.length-1) + 0;
              String random = activity[r] + " at the " + location[r1];
              txt2 = (TextView) findViewById(R.id.textView4);
              txt2.setText(random);

          }
    });
    }
}
