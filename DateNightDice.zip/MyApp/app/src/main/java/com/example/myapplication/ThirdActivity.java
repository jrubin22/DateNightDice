package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Arrays;
import android.view.View.OnClickListener;


public class ThirdActivity extends AppCompatActivity {
    Button loc;
    Button cont2;
    EditText edit1;
    TextView txt1;
    String location[] = new String[6];
    String[] activity = new String[6];
    int j = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState)

    {
        Intent intent = getIntent();
         activity = intent.getStringArrayExtra("activityPass");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);

        loc = (Button) findViewById(R.id.button1);
        loc.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                //while(location[j] != null || location[j] != "") {
                    if (j < 6) {
                        edit1 = (EditText) findViewById(R.id.editText2);
                        String getloc = edit1.getText().toString();
                        location[j] = getloc;
                        txt1 = (TextView) findViewById(R.id.textView2);
                        txt1.append(location[j] + "\n");
                        j++;
                   // }
                }
                edit1.getText().clear();
            }
        });

        cont2 = (Button) findViewById(R.id.button5);
        cont2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                launchFourthActivity(view);
            }

        });

    }
    public void launchFourthActivity(View view) {
        Intent intent = new Intent(this, Main2Activity.class);
        intent.putExtra("activityPass", activity);
        intent.putExtra("locationPass", location);
        startActivity(intent);
    }
}
