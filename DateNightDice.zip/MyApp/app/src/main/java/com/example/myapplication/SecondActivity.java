package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Arrays;
import android.view.View.OnClickListener;

public class SecondActivity extends AppCompatActivity {

    Button act;
    Button cont;

    EditText edit;

    TextView txt;

    String activity[] = new String[6];
   // int j = 0;
    int i =0;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cont = (Button) findViewById(R.id.button3);
        act = (Button) findViewById(R.id.button);
        act.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
               // while(activity[i] != null || activity[i] != "") {
                    if (i < 6) {
                        edit = (EditText) findViewById(R.id.editText);
                        String getAct = edit.getText().toString();
                        //String getAct = "dog";
                        activity[i] = getAct;
                        txt = (TextView) findViewById(R.id.textView1);
                        txt.append(activity[i] + "\n");
                        i++;
                    }
            //    }
                edit.getText().clear();

            }
        });

        cont.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                launchThirdActivity(view);
            }

                               });

        Intent intent = getIntent();

    }
    public void launchThirdActivity(View view) {
        Intent intent = new Intent(this, ThirdActivity.class);
       // String activityPass[] = activity;
        intent.putExtra("activityPass", activity);

        startActivity(intent);
    }
}